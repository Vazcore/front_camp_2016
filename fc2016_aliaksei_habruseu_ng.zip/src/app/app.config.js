export default {
  //host: 'http://localhost:8080/'
  host: 'https://shrouded-reaches-35443.herokuapp.com/'
};